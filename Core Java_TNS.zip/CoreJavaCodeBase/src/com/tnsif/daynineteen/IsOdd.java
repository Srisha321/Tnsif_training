//Program to demonstrate Functional Interface
package com.tnsif.daynineteen;

@FunctionalInterface
interface IsOdd{
	public boolean checkOdd(int a);
}
