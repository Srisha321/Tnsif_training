package com.tnsif.daynineteen;

@FunctionalInterface
public interface Message{  
    public void greet(String name);    
 } 

