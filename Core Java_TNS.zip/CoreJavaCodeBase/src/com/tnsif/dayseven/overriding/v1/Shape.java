//Program to define Base class Shape
package com.tnsif.dayseven.overriding.v1;


public class Shape {

	// Member function
	public void draw() {
		System.out.println("Drawing a generic shape");
	}

	public void erase() {
		System.out.println("Erasing a generic shape");
	}
}
