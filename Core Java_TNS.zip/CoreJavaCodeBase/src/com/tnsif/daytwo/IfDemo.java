//Program to guess a number in a given range
package com.tnsif.daytwo;

public class IfDemo {

	public static void main(String[] args) {

		int x = 5;
		if (x != 5)
			System.out.println("Value of x is not 5");
		System.out.println("Value of x is 5");
	}

}