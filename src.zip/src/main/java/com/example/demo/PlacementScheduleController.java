package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/placement")
public class PlacementScheduleController {

    @Autowired
    private PlacementScheduleService scheduleService;

    @PostMapping("/schedule")
    public PlacementSchedule schedulePlacement(@RequestBody PlacementSchedule schedule) {
        return scheduleService.createSchedule(schedule);
    }

    @GetMapping("/all")
    public List<PlacementSchedule> getAllSchedules() {
        return scheduleService.getAllSchedules();
    }
}