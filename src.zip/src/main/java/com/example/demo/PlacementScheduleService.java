package com.example.demo;

import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PlacementScheduleService {

    private final PlacementScheduleRepository repository;

    public PlacementScheduleService(PlacementScheduleRepository repository) {
        this.repository = repository;
    }

    public PlacementSchedule createSchedule(PlacementSchedule schedule) {
        return repository.save(schedule);
    }

    public List<PlacementSchedule> getAllSchedules() {
        return repository.findAll();
    }
}
