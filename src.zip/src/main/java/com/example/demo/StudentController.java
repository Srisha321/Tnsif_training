package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/student")
public class StudentController {

    @Autowired
    private StudentRepository studentRepo;

    // Add a new student
    @PostMapping("/add")
    public ResponseEntity<String> addStudent(@RequestBody Student student) {
        try {
            studentRepo.save(student);
            return ResponseEntity.ok("Student data added successfully.");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Error saving student data.");
        }
    }

    // Get certificate by student name and hall ticket number
    @GetMapping("/certificate")
    public ResponseEntity<String> getCertificate(
            @RequestParam String studentName,
            @RequestParam String hallTicketNumber) {

        Optional<Student> student = studentRepo.findByStudentNameAndHallTicketNumber(studentName, hallTicketNumber);

        return student.map(value -> ResponseEntity.ok(value.getCertificate()))
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).body("Certificate not found."));
    }

    @PutMapping("/update/by-name")
    public ResponseEntity<String> updateByStudentName(@RequestParam String studentName, @RequestBody Student updatedStudent) {
        Optional<Student> existingStudent = studentRepo.findByStudentName(studentName);

        if (existingStudent.isPresent()) {
            Student student = existingStudent.get();
            student.setStudentName(updatedStudent.getStudentName());
            student.setQualification(updatedStudent.getQualification());
            student.setCourse(updatedStudent.getCourse());
            student.setYearOfPassing(updatedStudent.getYearOfPassing());
            student.setHallTicketNumber(updatedStudent.getHallTicketNumber());
            student.setCertificate(updatedStudent.getCertificate());

            studentRepo.save(student);
            return ResponseEntity.ok("Student updated successfully.");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Student not found with name: " + studentName);
        }
    }

    // Delete student by ID
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> deleteStudent(@PathVariable Long id) {
        Optional<Student> student = studentRepo.findById(id);

        if (student.isPresent()) {
            studentRepo.delete(student.get());
            return ResponseEntity.ok("Student deleted successfully.");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Student not found.");
        }
    }
}
