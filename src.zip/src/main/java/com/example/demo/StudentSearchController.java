package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/search")
public class StudentSearchController {

    @Autowired
    private StudentRepository studentRepository;

    @GetMapping
    public ResponseEntity<List<Student>> searchStudents(@RequestParam("query") String query) {
        List<Student> results = studentRepository
            .findByStudentNameContainingIgnoreCaseOrHallTicketNumberContainingIgnoreCase(query, query);
        return ResponseEntity.ok(results);
    }
}
